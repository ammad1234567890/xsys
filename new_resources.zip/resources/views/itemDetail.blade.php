@extends('layouts.app')

@section('content')

        <div class="container-fluid">
    	<itemdetail-component></itemdetail-component>
        </div>

@endsection