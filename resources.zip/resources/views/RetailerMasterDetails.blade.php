@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <retailermasterdetails-component></retailermasterdetails-component>
    </div>
@endsection