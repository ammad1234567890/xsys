export const constant = new Vue({
    data: {
        base_url:'http://172.16.1.253:82/xsys_new_version/public/'
        //base_url:'http://portal.xcell.com.pk/system/public/'
    }
})