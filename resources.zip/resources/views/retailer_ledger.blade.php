@extends('layouts.app')

@section('content')

      <div class="container-fluid">
            <retailerledger-component></retailerledger-component>
       </div>


@endsection
