@extends('layouts.app')

@section('content')

        <div class="container-fluid">
    	<productdetail-component></productdetail-component>
        </div>

@endsection