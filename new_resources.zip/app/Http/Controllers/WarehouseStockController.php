<?php

namespace App\Http\Controllers;

use App\WarehouseStock;
use App\WarehouseStockItem;
use App\WarehouseStockTypeDetails;
use Illuminate\Http\Request;
use Auth;
use App\warehouseStaff;
use App\MainWarehouseReceiveItem;
use DB;

class WarehouseStockController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
    	return view('warehouseStock');
    }

    public function allStock()
    {
    	$warehouseStock=WarehouseStock::with('warehouse','productColor.product')->get();
    	return $warehouseStock;
    }

    public function warehouseStockSearch($id)
    {
        $searchStock=WarehouseStock::where('warehouse_id',$id)->with(
            'warehouse',
            'productColor.product','warehouse_stock_details')->get();
        return $searchStock;
    }

    public function searchStockDetails($id)
    {
        //$searchStock=WarehouseStockItem::all();
        // $searchStock=WarehouseStockItem::where('warehouse_id',5)->get();
        $searchStock=WarehouseStockItem::where('warehouse_id',$id)->with('warehouse','item.productColor.product','item.imei')->get();
        return $searchStock;
        //return $id;
    }

    public function stock_item_detail(){
        return View('stock_item_detail');
    }

    public function cons_stock_item_detail(){
        return View('consolidatedWarehouseStock');
    }

    public function stock_item_history(){
        return View('stockItemHistory');
    }
    public function get_specific_warehouse_item(Request $request)
    {
     /*   $warehouse_id=$request->input('warehouse_id');
        $product_id= $request->input('product_id');
        $product_color_id= $request->input('product_color_id');
        return DB::select("
              Select * from 
              tbl_main_warehouse_receive_item warehouse_item 
              inner join tbl_imei imei 
              on imei . item_id = warehouse_item . item_id 
              inner join tbl_item items
              on items.id=warehouse_item.item_id
              where 
              warehouse_item . warehouse_id = '$warehouse_id' 
              AND imei . product_id = '$product_id' AND 
              items.product_color_id='$product_color_id' 
              AND warehouse_item.is_sold=0"); */
		
		$warehouse_id=$request->input('warehouse_id');
        $product_id= $request->input('product_id');
        $product_color_id= $request->input('product_color_id');
        return DB::select("
              Select imei.imei1, imei.imei2, imei.item_id from 
              tbl_main_warehouse_receive_item warehouse_item 
              inner join tbl_imei imei 
              on imei . item_id = warehouse_item . item_id 
              inner join tbl_item items
              on items.id=warehouse_item.item_id
              where 
              warehouse_item . warehouse_id = '$warehouse_id' 
              AND imei . product_id = '$product_id' AND 
              items.product_color_id='$product_color_id' 
              AND warehouse_item.is_sold=0 AND warehouse_item.current_stock_status=1");
    }


    public function get_specific_item_history($warehouse_id, $product_color_id){
        return DB::select("(Select IF(transfer.transfer_qty > 0, 'Issued', '') as status_for, 
        transfer.created_at, 
        transfer.id as transfer_id, 
        transfer.transfer_qty as Transfer_qty, 
        transfer_warehouse.name as transfer_warehouse_name, 
        transfer.product_unit_price as unit_price, 
        issue_note.win_no as resource,
        transfer.created_at as transfer_date 
      from tbl_warehouse_stock warehouse_stock 
      left join tbl__warehouse__transfer transfer on transfer.previous_warehouse_id=warehouse_stock.warehouse_id 
      inner join tbl_warehouse transfer_warehouse on transfer_warehouse.id=transfer.new_warehouse_id 
      inner join warehouse_issue_note issue_note on issue_note.id=transfer.resource_id
      where warehouse_stock.warehouse_id='$warehouse_id' 
      AND warehouse_stock.product_color_id='$product_color_id' 
      AND transfer.product_color_id='$product_color_id' order by transfer.id DESC)
      
      UNION

(Select IF(transfer.transfer_qty > 0, 'Received', '') as status_for, 
transfer.created_at, 
transfer.id as transfer_id,
transfer.transfer_qty as Transfer_qty, 
transfer_warehouse.name as transfer_warehouse_name, 
transfer.product_unit_price as unit_price, 
issue_note.win_no as resource,
transfer.created_at as transfer_date 
from tbl_warehouse_stock warehouse_stock 
left join tbl__warehouse__transfer transfer on transfer.new_warehouse_id=warehouse_stock.warehouse_id 
inner join tbl_warehouse transfer_warehouse on transfer_warehouse.id=transfer.previous_warehouse_id 
inner join warehouse_issue_note issue_note on issue_note.id=transfer.resource_id
where warehouse_stock.warehouse_id='$warehouse_id' AND warehouse_stock.product_color_id='$product_color_id' AND transfer.product_color_id='$product_color_id' 
order by transfer.id DESC)

UNION

(Select IF(receive_products.product_qty > 0, 'Received', '') as status_for,
main_receive.created_at,
main_receive.id as transfer_id,
receive_products.product_qty as Transfer_qty,
IF(receive_products.product_qty > 0, 'Port', '') as transfer_warehouse_name, 
manu_order_prod.unit_cost as unit_price,
receive.receive_no as resource,
main_receive.created_at as transfer_date  
from tbl_main_warehouse_receive main_receive
inner join tbl_main_warehouse_receive_product receive_products on receive_products.main_receive_id=main_receive.id
inner join tbl_receive receive on receive.id=main_receive.receive_id
inner join tbl_manufacturing_order_product manu_order_prod on manu_order_prod.manufacture_order_id=receive.manufacturing_order_id
where main_receive.warehouse_id='$warehouse_id' AND receive_products.product_color_id='$product_color_id' AND manu_order_prod.product_color_id='$product_color_id')

UNION

(SELECT IF(products.product_qty > 0, 'Issued', '') as status_for, 
orders.created_at,
orders.id as transfer_id,
products.product_qty, 
outlet.name as transfer_warehouse_name,

products.unit_price as unit_price, 
invoice.invoice_no as resource,
orders.created_at as transfer_date

FROM `tbl_retailer_order` orders
 inner join tbl_retailer_order_products products on products.retailer_order_id=orders.id
 inner join tbl_retailer_outlet outlet on outlet.id=orders.outlet_id
 inner join tbl_invoice invoice on invoice.order_id=orders.id
 where orders.warehouse_id='$warehouse_id' AND products.product_color_id='$product_color_id' order by orders.created_at DESC)
");

    }

    public function get_specific_item_supply_history($warehouse_id, $product_color_id){
        return DB::select("SELECT products.unit_price, products.product_qty, orders.created_at, outlet.name as outlet_name FROM `tbl_retailer_order` orders
              inner join tbl_retailer_order_products products on products.retailer_order_id=orders.id
              inner join tbl_retailer_outlet outlet on outlet.id=orders.outlet_id
              where orders.warehouse_id='$warehouse_id' AND products.product_color_id='$product_color_id' order by orders.created_at DESC");
    }


    public function get_warehouse_stock_by_warehouse_id($warehouse_id, $product_color_id){
        return WarehouseStock::with('warehouse')->where('warehouse_id', $warehouse_id)->where('product_color_id', $product_color_id)->get();
    }
	
	public function get_warehouse_instock_items(Request $request){
        $userId=Auth::user()->staff_id;
        $warehouse_details=warehouseStaff::with('warehouse')->where('staff_id',$userId)->get();
        $warehouse_id= $warehouse_details[0]['warehouse']['id'];


        if ( $request->input('client') ) {
            return MainWarehouseReceiveItem::where('warehouse_id',$warehouse_id)->where('is_sold', 0)->with('item.productColor.product','item.imei')->get();
        }
        $columns = ['warehouse_id', 'current_stock_status', 'item_id'];
        $length = $request->input('length');
        $column = $request->input('column'); //Index
        $dir = $request->input('dir');
        $searchValue = $request->input('search');


        $query = MainWarehouseReceiveItem::where('warehouse_id',$warehouse_id)->where('is_sold', 0)->with('item.productColor.product','item.imei')->orderBy($columns[$column], $dir);
        if ($searchValue) {
            $query->where(function($query) use ($searchValue) {
                $query->orWhereHas('item.imei', function ( $q ) use ($searchValue) {
                        $q->Where('imei1', 'like', '%' . $searchValue . '%');
                    })
                    ->orWhereHas('item.imei', function ( $q ) use ($searchValue) {
                        $q->Where('imei2', 'like', '%' . $searchValue . '%');
                    })->orWhereHas('item.productColor.product', function ( $q ) use ($searchValue) {
                        $q->Where('name', 'like', '%' . $searchValue . '%');
                    })->orWhereHas('item.productColor', function ( $q ) use ($searchValue) {
                        $q->Where('color', 'like', '%' . $searchValue . '%');
                    });

            });
        }
        $projects = $query->paginate($length);
        return ['data' => $projects, 'draw' => $request->input('draw')];
    }


   public function get_warehouse_sold_items(Request $request){
        $userId=Auth::user()->staff_id;
        $warehouse_details=warehouseStaff::with('warehouse')->where('staff_id',$userId)->get();
        $warehouse_id= $warehouse_details[0]['warehouse']['id'];


        if ( $request->input('client') ) {
            return MainWarehouseReceiveItem::where('warehouse_id',$warehouse_id)->where('is_sold', 1)->with('outlet','item.productColor.product','item.imei')->get();
        }
        $columns = ['warehouse_id', 'current_stock_status', 'item_id'];
        $length = $request->input('length');
        $column = $request->input('column'); //Index
        $dir = $request->input('dir');
        $searchValue = $request->input('search');


        $query = MainWarehouseReceiveItem::where('warehouse_id',$warehouse_id)->where('is_sold', 1)->with('outlet','item.productColor.product','item.imei')->orderBy($columns[$column], $dir);
        if ($searchValue) {
            $query->where(function($query) use ($searchValue) {
                $query->orWhereHas('item.imei', function ( $q ) use ($searchValue) {
                    $q->Where('imei1', 'like', '%' . $searchValue . '%');
                })
                    ->orWhereHas('item.imei', function ( $q ) use ($searchValue) {
                        $q->Where('imei2', 'like', '%' . $searchValue . '%');
                    })->orWhereHas('item.productColor.product', function ( $q ) use ($searchValue) {
                        $q->Where('name', 'like', '%' . $searchValue . '%');
                    })->orWhereHas('item.productColor', function ( $q ) use ($searchValue) {
                        $q->Where('color', 'like', '%' . $searchValue . '%');
                    })->orWhereHas('outlet', function ( $q ) use ($searchValue) {
                        $q->Where('name', 'like', '%' . $searchValue . '%');
                    });

            });
        }
        $projects = $query->paginate($length);
        return ['data' => $projects, 'draw' => $request->input('draw')];
    }
}
