@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <productspecification-component></productspecification-component>
    </div>
@endsection