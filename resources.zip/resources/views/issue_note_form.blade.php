@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <issuenoteform-component></issuenoteform-component>
    </div>
@endsection