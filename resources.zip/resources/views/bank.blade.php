@extends('layouts.app')

@section('content')

        <div class="container-fluid">
            <bank-component></bank-component>
        </div>

@endsection
