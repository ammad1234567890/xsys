@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <stockitemhistory-component></stockitemhistory-component>
    </div>
@endsection