@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <allretailers-component></allretailers-component>
    </div>

@endsection
