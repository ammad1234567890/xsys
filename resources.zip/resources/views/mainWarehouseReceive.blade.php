@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<mainwarehousereceive-component></mainwarehousereceive-component>
		</div>
@endsection
