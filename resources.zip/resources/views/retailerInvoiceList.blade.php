@extends('layouts.app')
@section('content')

    <div class="container-fluid">
        <retailerlist-component></retailerlist-component>
    </div>
@endsection

