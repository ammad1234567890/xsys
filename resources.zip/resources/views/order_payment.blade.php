@extends('layouts.app')

@section('content')

        <div class="container-fluid">
    <orderpayment-component></orderpayment-component>
        </div>

@endsection
