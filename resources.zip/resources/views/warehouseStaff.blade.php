@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<warehousestaff-component></warehousestaff-component>
        </div>
@endsection
