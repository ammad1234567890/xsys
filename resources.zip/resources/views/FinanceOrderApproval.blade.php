@extends('layouts.app')

@section('content')

        <div class="container-fluid">
            <financeorderapproval-component></financeorderapproval-component>
        </div>

@endsection
