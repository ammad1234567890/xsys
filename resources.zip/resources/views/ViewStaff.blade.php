@extends('layouts.app')

@section('content')

        <div class="container-fluid">
                <viewstaff-component></viewstaff-component>
        </div>
@endsection
