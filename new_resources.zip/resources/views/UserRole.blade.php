@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<userrole-component></userrole-component>
        </div>

@endsection
