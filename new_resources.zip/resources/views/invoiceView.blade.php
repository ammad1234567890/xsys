@extends('layouts.app')

@section('content')

    <div class="container-fluid">
  		<invoiceview-component></invoiceview-component>
  	</div>



@endsection
