@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <receivetransferstock-component></receivetransferstock-component>
    </div>
@endsection
