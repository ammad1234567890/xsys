@extends('layouts.app')

@section('content')
        <div class="container-fluid">
        	<!--<stockitemdetail-component></stockitemdetail-component> -->
            <warehousestock-component></warehousestock-component>

        </div>
@endsection
