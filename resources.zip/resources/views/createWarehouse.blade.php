@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<createwarehouse-component></createwarehouse-component>
        </div>
@endsection
