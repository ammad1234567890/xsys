@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <displayissuenote-component></displayissuenote-component>
    </div>
@endsection
