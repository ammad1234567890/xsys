@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<warehouse-component></warehouse-component>
        </div>
@endsection
