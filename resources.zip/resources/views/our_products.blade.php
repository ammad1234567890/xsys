@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <productspecs-component></productspecs-component>
    </div>
@endsection