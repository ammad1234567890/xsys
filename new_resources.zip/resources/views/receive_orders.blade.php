@extends('layouts.app')

@section('content')

        <div class="container-fluid">
    <receiveorders-component></receiveorders-component>
        </div>

@endsection