@extends('layouts.app')

@section('content')
        <div class="container-fluid">
        	<showproduct-component></showproduct-component>
        </div>
@endsection