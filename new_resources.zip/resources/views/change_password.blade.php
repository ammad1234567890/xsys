@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <changepassword-component></changepassword-component>
    </div>

@endsection