@extends('layouts.app')

@section('content')

        <div class="container-fluid">
    <order-component></order-component>
        </div>
@endsection
