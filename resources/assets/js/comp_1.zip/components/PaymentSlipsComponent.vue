<template>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-info" >
                <div class="panel-heading">
                    <h2 class="panel-title">Dealer Payments</h2>
                </div>
                <div class="panel-body">
                    <div class="col-md-12">
                        <table id="bank_detail_table" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                            <thead>
                            <tr>
                                <th>Date</th>
                                <th>DS.No</th>
                                <th>Dealer Code</th>
                                <th>Outlet</th>
                                <th>Bank</th>
                                <th class="col-md-2">Payment Type</th>
                                <th>Total Amount</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr v-for="(slip, index) in ds">
                                <td><b>{{slip.created_at | moment}}</b></td>
                                <td>{{slip.deposit_slip_number}}</td>
                                <td>{{slip.retailer.retailer_no}}</td>
                                <td>{{slip.retailer_outlet.name}}</td>
                                <td>{{slip.bank.bank_name}}</td>
                                <td class="col-md-2"><b>{{slip.payment_type.type}}</b></td>
                                <td>{{slip.total_amount | currency('Rs')}}</td>
                                <td>

                                    <span v-if="slip.payment_type.id==3">
                                        <a :href="'../retailer_order/order_payment_reversal/'+slip.id">
                                            <button class="btn btn-xs btn-danger" title="Reverse Payment"><i class="fa fa-undo"></i></button>
                                        </a>
                                    </span>
                                    <button class="btn btn-xs btn-primary" @click="get_ds_details(slip.id)"><span class="fa fa-eye"></span></button>

                                </td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade bs-add-Model-modal-md" tabindex="5" role="dialog"  id="payment_details_modal" aria-labelledby="bs-add-Model-modal-md">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Collection Details</h4>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-md-12">
                                <h5><b>Deposit Slip: </b>{{this.ds_details.deposit_slip_number}}</h5>
                                <h5><b>Total Amount: </b>{{this.ds_details.total_amount}}</h5>
                                <h5><b>Outlet: </b>{{this.outlet}}</h5>
                                <table class="table table-striped table-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>Invoice No/Advance</th>
                                        <th>Amount</th>
                                        <th>Cheque/Cash</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(details, index) in ds_details.get_ds_collections">
                                            <td><span v-if="details.invoice_id!=null" style="color: green; font-weight:bold;">{{details.invoice.invoice_no}}</span><span v-else  style="color: orange; font-weight:bold;">Advance</span></td>
                                            <td>{{details.amount}}</td>
                                            <td><span v-if="details.cheque_number!=null">{{details.cheque_number}}</span><span v-else>Cash</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">

                    </div>
                </div>
            </div>
        </div>


    </div>

</template>
<script>
    import {constant} from '../constant.js';
    export default {

        data() {
            return {
                ds:[],
                ds_details:[],
                outlet:"",
            }
        },
        created(){
            this.get_all_ds();
        },
        filters: {
            moment: function (date) {
                return moment(date).format('DD-MM-YYYY');
            }
        },
        methods:{
            get_all_ds:function(){
                axios.get("../retailer/deposit_slips").then((response) =>{
                    this.ds=response.data;
                });
            },
            get_ds_details: function(id){
                axios.get(constant.base_url+"deposit_slip_details/"+id).then((response)=>{
                    this.ds_details=response.data[0];
                    this.outlet=response.data[0].retailer_outlet.name;
                    $('#payment_details_modal').modal('show');
                });
            }
        }
    }
</script>
