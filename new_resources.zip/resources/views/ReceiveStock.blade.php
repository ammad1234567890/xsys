@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <receivestock-component></receivestock-component>
    </div>
@endsection
