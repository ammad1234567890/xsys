@extends('layouts.app')

@section('content')

        <div class="container-fluid">
    <receive-component></receive-component>
        </div>

@endsection
