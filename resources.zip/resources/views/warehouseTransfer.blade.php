@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<warehousetransfer-component></warehousetransfer-component>
        </div>
@endsection
