@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<showcategory-component></showcategory-component>
        </div>
@endsection
