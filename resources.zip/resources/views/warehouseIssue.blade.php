@extends('layouts.app')

@section('content')

    <div class="container-fluid">
		<warehouseissue-component></warehouseissue-component>
	</div>
@endsection
