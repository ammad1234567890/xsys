<?php
namespace App\Http\Controllers\API;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\DealerAuth;
use App\Retailer;
use App\RetailerOutlet;
use App\MainWarehouseReceiveItem;
use App\Ledger;
use Validator;
use Auth;
use Hash;
use DB;


class ImeiActivationController extends Controller
{
    public $successStatus = 200;

    public function activate_imei(Request $request){
        $item_id= $request->input('item_id');
        $dealer_Response= $request->input('dealer_response');

        if($dealer_Response==1){
            MainWarehouseReceiveItem::where('item_id', $item_id)->update(['item_is_activate'=>1, 'activated_date'=> date('Y-m-d H:i:s')]);
            $response=array(
                'status'=>1,
                'status_code'=>200,
                'message'=>'Imei has been Activated',
                'data'=>[],
            );

            return response()->json($response);
        }
        else{
            $response=array(
                'status'=>1,
                'status_code'=>406,
                'message'=>'Cancel',
                'data'=>[],
            );

            return response()->json($response);
        }

    }
	 
}
