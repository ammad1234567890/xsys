@extends('layouts.app')
@section('content')

<div class="container-fluid">
    <salefind-component></salefind-component>
</div>

@endsection

