@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<staff-component></staff-component>
        </div>
@endsection
