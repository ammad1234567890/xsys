<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvoiceProductsReturn extends Model
{
    protected $table="tbl_invoice_products_return";
}
