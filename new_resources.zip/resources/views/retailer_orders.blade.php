@extends('layouts.app')

@section('content')

        <div class="container-fluid">
    <retailerorders-component></retailerorders-component>
        </div>

@endsection
