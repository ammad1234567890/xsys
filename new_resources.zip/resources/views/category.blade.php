@extends('layouts.app')
@section('content')

        <div class="container-fluid">
            <category-component></category-component>
        </div>


@endsection