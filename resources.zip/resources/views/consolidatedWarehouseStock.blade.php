@extends('layouts.app')

@section('content')
        <div class="container-fluid">
        	<consolidated-stockitemdetail-component></consolidated-stockitemdetail-component>
        </div>
@endsection
