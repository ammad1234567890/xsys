@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <consignmentstockentry-component></consignmentstockentry-component>
    </div>

@endsection