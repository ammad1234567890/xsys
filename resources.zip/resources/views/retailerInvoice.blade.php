@extends('layouts.app')
@section('content')

    <div class="container-fluid">
  <retailerinvoice-component></retailerinvoice-component>
 	</div>

@endsection

