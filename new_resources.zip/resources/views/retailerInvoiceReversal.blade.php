@extends('layouts.app')
@section('content')

    <div class="container-fluid">
  <retailerinvoicereversal-component></retailerinvoicereversal-component>
 	</div>

@endsection

