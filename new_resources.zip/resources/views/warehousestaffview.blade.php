@extends('layouts.app')

@section('content')

        <div class="container-fluid">
                <warehousestaffview-component></warehousestaffview-component>
        </div>
@endsection