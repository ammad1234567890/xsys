@extends('layouts.app')

@section('content')



                <div class="container-fluid">
                        

                        <collection-component></collection-component>

                    
                </div>

        
@endsection