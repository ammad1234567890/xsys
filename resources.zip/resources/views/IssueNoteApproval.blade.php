@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<issuenoteapproval-component></issuenoteapproval-component>
        </div>
@endsection

