@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <!--<stockitemdetail-component></stockitemdetail-component> -->
        <paymentslips-component></paymentslips-component>

    </div>
@endsection