@extends('layouts.app')

@section('content')

        <div class="container-fluid">
<role-component></role-component>
        </div>

@endsection
