@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <!--<stockitemdetail-component></stockitemdetail-component> -->
        <paymentreverse-component></paymentreverse-component>

    </div>
@endsection
