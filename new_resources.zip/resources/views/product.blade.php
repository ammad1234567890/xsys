@extends('layouts.app')
@section('content')

        <div class="container-fluid">
            <product-component></product-component>
        </div>


@endsection