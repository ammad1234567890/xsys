@extends('layouts.app')

@section('content')

        <div class="container-fluid">
    <createretailerorders-component></createretailerorders-component>
        </div>

@endsection
