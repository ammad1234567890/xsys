@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <transferrequest-component></transferrequest-component>
    </div>
@endsection
