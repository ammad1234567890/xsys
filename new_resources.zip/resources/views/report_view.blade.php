@extends('layouts.app')
@section('content')

    <div class="container-fluid">
  <reports-component></reports-component>
 	</div>

@endsection

