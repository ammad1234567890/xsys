@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <retailer-outlet-component></retailer-outlet-component>
    </div>

@endsection

